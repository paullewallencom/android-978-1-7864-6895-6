package com.androcid.zomato.activity.base;

import android.support.v7.app.AppCompatActivity;

/**
 * To handle activity Transitions
 */

public class TransitionBaseActivity extends AppCompatActivity {

}
