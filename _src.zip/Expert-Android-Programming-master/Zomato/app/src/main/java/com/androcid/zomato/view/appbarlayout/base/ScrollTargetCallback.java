

package com.androcid.zomato.view.appbarlayout.base;

import android.view.View;

/**
 * Created by Androcid on 2/2/16.
 */
public interface ScrollTargetCallback {

  View callback(View target);
}
