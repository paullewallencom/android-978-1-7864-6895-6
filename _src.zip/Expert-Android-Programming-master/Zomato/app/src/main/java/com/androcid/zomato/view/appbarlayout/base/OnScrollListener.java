

package com.androcid.zomato.view.appbarlayout.base;

import android.view.View;

/**
 * Created by Androcid on 2/3/16.
 */
public interface OnScrollListener {

  void onScrollChanged(View view, int x, int y, int dx, int dy, boolean accuracy);
}
