package com.androcid.zomato.service;

/**
 * Created by Androcid on 28-10-2015.
 */
public class ImageUploadItem {
    boolean b;

    public ImageUploadItem(boolean b) {
        this.b = b;
    }
}
