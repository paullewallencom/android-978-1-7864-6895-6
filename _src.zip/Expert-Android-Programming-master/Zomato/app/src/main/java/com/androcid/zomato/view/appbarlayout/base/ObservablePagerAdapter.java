

package com.androcid.zomato.view.appbarlayout.base;

/**
 * Created by Androcid on 2/11/16.
 */
public interface ObservablePagerAdapter {

  ObservableFragment getObservableFragment(int position);
}
