package com.androcid.zomato.dao;

public class Dao {	

	public static final String DATABASE = "zomato_database";
	public static final String PASSWORD = "5tsv879";

	public static final String CREATE_TABLE = " CREATE TABLE ";
	public static final String START_TABLE = " (";
	public static final String END_TABLE = ");";
	public static final String COMMA = " , ";
	public static final String IF_NOT_EXIST = "IF NOT EXISTS ";
	public static final String TYPE_TEXT_PRIMARY = " TEXT PRIMARY KEY ";
	public static final String TYPE_INTEGER_PRIMARY = " INTEGER PRIMARY KEY ";
	public static final String TYPE_TEXT = " TEXT ";
    public static final String TYPE_INTEGER = " INTEGER ";
    public static final String TYPE_REAL = " REAL ";
	
	
	public static final String COLUMN_ID = "_id";
	public static final String Q = "'";
	public static final String ID = "id";
}
